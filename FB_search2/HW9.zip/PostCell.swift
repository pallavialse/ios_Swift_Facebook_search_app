//
//  PostCell.swift
//  FB_search2
//
//  Created by pallavi alse on 4/23/17.
//  Copyright © 2017 pallavi alse. All rights reserved.
//

import UIKit

class PostCell: UITableViewCell {

    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var textArea: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
   

}
